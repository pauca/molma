
sdfSummary<-function(data){
  
  
}